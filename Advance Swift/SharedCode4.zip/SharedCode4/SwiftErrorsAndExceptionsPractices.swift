

import Foundation

//_________________________________________________________

// Summation Type
enum ParseLocationError: Error {
    case invalidData
    case locationDoesNotExist
    case middleOfTheOcean
}

// Product Type
struct MultipleParseLocationErrors: Error {
    let parsingErrors: [ParseLocationError]
    let isShownToUser: Bool
}

struct Location {
    let latitude: Double
    let longitude: Double
}

//_________________________________________________________

func parseLocation(_ latitude: String, _ longitude: String) throws -> Location {
    guard let latitude = Double(latitude), let longitude = Double(longitude) else {
        throw ParseLocationError.invalidData
    }
    
    return Location(latitude: latitude, longitude: longitude)
}

// error: call can throw but is not marked with 'try'
// parseLocation("I am not a double", "110")

do {
    try parseLocation("I am not a double", "110")
} catch {
    print(error) // invalidData
}

//_________________________________________________________


enum ListError: Error {
    case invalidValue
}

struct TodoList {
    
    private var values = [String]()

    // BAD DESIGN    
    // mutating func append(strings: [String]) throws {
    //    for string in strings {
    //        let trimmedString = string.trimmingCharacters(in: .whitespacesAndNewlines)

    //        if trimmedString.isEmpty {
    //            throw ListError.invalidValue
    //        } else {
    //            values.append(trimmedString)
    //        }
    //    }
    // }

    // GOOD DESIGN
    mutating func append(strings: [String]) throws {
        var trimmedStrings = [String]()
        for string in strings {
            let trimmedString = string.trimmingCharacters(in: .whitespacesAndNewlines)
            
            if trimmedString.isEmpty {
                throw ListError.invalidValue
            } else {
                trimmedStrings.append(trimmedString)
            }
        }
        
        // Only when everything succeeds, do we start mutating the struct.
        values.append(contentsOf: trimmedStrings)
    }

}

//_________________________________________________________

var number = 10
var divisor = 90
var result = 0

// BAD CODE DESIGN
// Validation Logic CAN BE DONE WITH JUST if-else construction
do {
    try result = number / divisor
} catch {
    print(error)
}

//_________________________________________________________


// import PlaygroundSupport

func writeToFiles(data: [URL: String]) throws {
    var storedUrls = [URL]()

    defer {
        if storedUrls.count != data.count {
            for url in storedUrls {
                try! FileManager.default.removeItem(at: url)
            }
        }
    }
    
    for (url, contents) in data {
        try contents.write(to: url, atomically: true, encoding: String.Encoding.utf8)
        storedUrls.append(url)
    }
}

// let url = playgroundSharedDataDirectory.appendingPathComponent("somefile.txt")
let api = "https://api.github.com"
let endpoint = "/search/repositories"
let url: URL! = URL(string: api + endpoint)

do {
    try writeToFiles(data: [url: "Hello there"])
} catch {
    print(error)
}


//_________________________________________________________

// ERROR PROPAGATION

import Foundation

struct Recipe {
    let ingredients: [String]
    let steps: [String]
}

enum ParseRecipeError: Error {
    case parseError(line: Int, symbol: String)
    case noRecipeDetected
    case noIngredientsDetected
}


extension ParseRecipeError: LocalizedError {
    var errorDescription: String? {
        switch self {
        case .parseError:
            return NSLocalizedString("The HTML file had unexpected symbols.",
                                     comment: "Parsing error reason unexpected symbols")
        case .noIngredientsDetected:
            return NSLocalizedString("No ingredients were detected.",
                                     comment: "Parsing error no ingredients.")
        case .noRecipeDetected:
            return NSLocalizedString("No recipe was detected.",
                                     comment: "Parsing error no recipe.")
        }
    }
    
    var failureReason: String? {
        switch self {
        case let .parseError(line: line, symbol: symbol):
            return String(format: NSLocalizedString("Parsing data failed at line: %i and symbol: %@",
                                                    comment: "Parsing error line symbol"), line, symbol)
        case .noIngredientsDetected:
            return NSLocalizedString("The recipe seems to be missing its ingredients.",
                                     comment: "Parsing error reason missing ingredients.")
        case .noRecipeDetected:
            return NSLocalizedString("The recipe seems to be missing a recipe.",
                                     comment: "Parsing error reason missing recipe.")
        }
    }
    
    var recoverySuggestion: String? {
        return "Please try a different recipe."
    }
    
}

extension ParseRecipeError: CustomNSError {
    static var errorDomain: String { return "com.recipeextractor" }
    
    var errorCode: Int { return 300 }
    
    var errorUserInfo: [String: Any] {
        return [
            NSLocalizedDescriptionKey: errorDescription ?? "",
            NSLocalizedFailureReasonErrorKey: failureReason ?? "",
            NSLocalizedRecoverySuggestionErrorKey: recoverySuggestion ?? ""
        ]
    }
}

let nsError: NSError = ParseRecipeError.parseError(line: 3, symbol: "#") as NSError
print(nsError)


// import UIKit

struct ErrorHandler {
    
    static let `default` = ErrorHandler()
    
    let genericMessage = "Sorry! Something went wrong"
    
    func handleError(_ error: Error) {
        presentToUser(message: genericMessage)
    }
    
    func handleError(_ error: LocalizedError) {
        if let errorDescription = error.errorDescription {
            presentToUser(message: errorDescription)
        } else {
            presentToUser(message: genericMessage)
        }
    }
    
    func presentToUser(message: String) {
        // Show alert dialog in iOS or OSX
        // ... snip
    }
}

// Removes the blabbing stories that people put in front of recipes and strips the actual recipe
struct RecipeExtractor {
    
    let html: String
    
    func extractRecipe() throws -> Recipe {
        return try parseHTML(html)
    }
    
    private func parseHTML(_ html: String) throws -> Recipe {
        let ingredients = try extractIngredients(html)
        let steps = try extractSteps(html)
        return Recipe(ingredients: ingredients, steps: steps)
    }
    
    private func extractIngredients(_ html: String) throws -> [String] {
        // ... Parsing happens here
        
        // .. Unless an error is thrown
        throw ParseRecipeError.noIngredientsDetected
    }
    
    private func extractSteps(_ html: String) throws -> [String] {
        // ... Parsing happens here
        
        // .. Unless an error is thrown
        throw ParseRecipeError.noRecipeDetected
    }
    
}

let html = "" // We can obtain html from a source
let recipeExtractor = RecipeExtractor(html: html)

do {
    let recipe = try recipeExtractor.extractRecipe()
    print(recipe)
} catch  {
    ErrorHandler.default.handleError(error)
}

//_________________________________________________________


// IMPROVE DESIGN For Following Code Example

enum ValidationError: Error {
    case noEmptyValueAllowed
    case invalidPhoneNumber
}

func validatePhoneNumber(_ text: String) throws {
    guard !text.isEmpty else {
        throw ValidationError.noEmptyValueAllowed
    }
    
    let pattern = "^(\\([0-9]{3}\\) |[0-9]{3}-)[0-9]{3}-[0-9]{4}$"
    if text.range(of: pattern, options: .regularExpression, range: nil, locale: nil) == nil {
        throw ValidationError.invalidPhoneNumber
    }
}

do {
    try validatePhoneNumber("(123) 123-1234")
    print("Phonenumber is valid")
} catch {
    print(error)
}

//_________________________________________________________
// BETTER DESIGN

struct PhoneNumber {    
    let contents: String
    
    init(_ text: String) throws {
        guard !text.isEmpty else {
            throw ValidationError.noEmptyValueAllowed
        }
        
        let pattern = "^(\\([0-9]{3}\\) |[0-9]{3}-)[0-9]{3}-[0-9]{4}$"
        if text.range(of: pattern, options: .regularExpression, range: nil, locale: nil) == nil {
            throw ValidationError.invalidPhoneNumber
        }
        self.contents = text
    }
}

do {
    let phoneNumber = try PhoneNumber("(123) 123-1234")
    print(phoneNumber.contents) // (123) 123-1234
} catch {
    print(error)
}

//_________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, RAISE YOUR HAND!!!

import Foundation
import PlaygroundSupport
import UIKit

//: Instead of throwing an error, we can return an optional

func loadFile(name: String) -> Data? {
    let url = playgroundSharedDataDirectory.appendingPathComponent(name)
    return try? Data(contentsOf: url)
}

// Attribute To Ignore Compiler Warning
@discardableResult func storeData(image: UIImage, url: URL) -> Bool {
    guard let data = image.pngData() else {
        return false
    }
    
    do {
        try data.write(to: url)
        return true
    } catch {
        return false
    }
}

let image = UIImage()
let url = playgroundSharedDataDirectory.appendingPathComponent("image")
storeData(image: image, url: url)

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
