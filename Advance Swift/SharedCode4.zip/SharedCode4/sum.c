
#include <stdio.h>

// Write Following sum Function With Given Signatures In C/C++/Java

// BAD CODE
int sum(int x, int y) {
	return x + y;
} 

// Write Following sum Function With Given Signatures In C/C++/Java
// 		Which Returns Valid Arithmatic Sum 
//		Otherwise Print Can't Calculate Valid Sum For Given x And y Values

#include <limits.h>

// Type Safe Code
int sumTyeSafe(signed int si_a, signed int si_b) {
   signed int result;
   if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
       ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
   		// Violation Of Closure Law
   		// print Can't Calculate Sum
   		/* Handle error */

   } else { // Following Closure Law
       result = si_a + si_b;
   }
   /* ... */
}

//_________________________________________________


In Swift
var a: Int8 = 127

a = a &+ 1 // &+ Operator Is Type UfSafe

int sumTypeUnsafe(int x, int y) {
	return x + y;
} 

//________________________________________________

In Swift
var a: Int8 = 127

a = a + 1 // + Operator Is Type Safe


#include <limits.h>

// Type Safe Code
int sumTyeSafe(signed int si_a, signed int si_b) {
   signed int result;
   if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
       ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
   		// Violation Of Closure Law
   		// print Can't Calculate Sum
   		/* Handle error */

   } else { // Following Closure Law
       result = si_a + si_b;
   }
   /* ... */
}

//________________________________________________

// DESIGN EXERCISE

// Write Following sum Function With Given Signatures In C/C++/Java
// 		Which Returns Valid Arithmatic Sum 
//		Otherwise Return Not Valid Result

#include <limits.h>

// DESIGN 1
// GLOBAL VARIBALE
//		Global Are Bad Idea
int sumTyeSafeError = 0;

// Type Safe Code
int sumTyeSafe(signed int si_a, signed int si_b) {
   signed int result;
   if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
       ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
 
 		sumTyeSafeError = 1
 		// return ______________

   } else { // Following Closure Law
       result = si_a + si_b;
   }
   /* ... */
}


// DESIGN 2

// DEFINE Error Code

// Semantic Mess
// #define SUCCESS 0
// #define FAILURE 1

// #define SUCCESS 1
// #define FAILURE 2

// Type Safe Code
int sumTyeSafe(signed int si_a, signed int si_b, int * Error) {
   signed int result;
   if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
       ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
 
 		sumTyeSafeError = 1
 		// return ______________

   } else { // Following Closure Law
	   return result = si_a + si_b;
   }
}




// DESIGN 3
typedef struct resultValue {
	int value;
	int error;
} Result;

// Type Safe Code
Result sumTyeSafe(signed int si_a, signed int si_b) {
   Result result;
   if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
       ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
 
 		result.error = 1
 		// return ______________

   } else { // Following Closure Law
	    result.value = si_a + si_b;
   		result.error = 0 
   }

   return result;
}

//_________________________________________________


// DESIGN FINAL
typedef struct optionalType {
	int value;
	int valid;
} Optional;

// Type Safe Code
Optional sumTyeSafe(signed int si_a, signed int si_b) {
   Result result;
   if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
       ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
 
 		result.valid = 0
 		// return ______________

   } else { // Following Closure Law
	   result.value = si_a + si_b;
	   result.valid = 1
   }

   return result;
}


//_________________________________________________


int main() {
	int a = 898989898; 
	int b = 10;
	int result = 0;

	result = sum(a, b);
	printf( "\n result : %d", result );

	a = 2147483647;
	b = 1;
	result = sum(a, b);
	printf( "\n result : %d", result );

	a = -2147483648;
	b = -1;
	result = sum(a, b);
	printf( "\n result : %d", result );
	return 0;
}

// result : 898989908
// result : -2147483648(base)

