 
 # Map, flatMap, and compactMap
 
 //___________________________________________________________________

PLEASE TRY ONE EXAMPLE AT A TIME
THIS IS CUMMULATIVE FILE OF ALL EXAMPLES
EXAMPLES ARE SEPERATED WITH FOLLOWING SEPERATOR LINE

//___________________________________________________________________

//___________________________________________________________________
//___________________________________________________________________


import Foundation

//: # Mapping over collections

// Iterative style
//func resolveCounts(statistics: [(String, Int)]) -> [String] {
//    var resolvedCommits = [String]()
//    for (name, count) in statistics {
//        let involvement: String
//
//        switch count {
//        case 0: involvement = "\(name) is not involved in the project"
//        case 1..<100: involvement =  "\(name) is not active on the project"
//        default: involvement =  "\(name) is active on the project"
//        }
//
//        resolvedCommits.append(involvement)
//    }
//    return resolvedCommits
//}

// Functional style

func resolveCounts(statistics: [(String, Int)]) -> [String] {
    return statistics.map { (name: String, count: Int) -> String in
        switch count {
        case 0: return "\(name) is not involved in the project"
        case 1..<100: return "\(name) is not very active on the project"
        default: return "\(name) is active on the project"
        }
    }
}

let commitStats = [
    (name: "Miranda", count: 30),
    (name: "Elly", count: 650),
    (name: "John", count: 0)
]

let readableStats = resolveCounts(statistics: commitStats)
print(readableStats) // ["Miranda is not very active on the project", "Elly is quite active", "John is not involved in the project"]


//: ## Pipeline vs for loop

func counts(statistics: [(String, Int)]) -> [Int] {
    return statistics
        .map { $0.1 }
        .filter { $0 > 0 }
        .sorted(by: >)
}

//func counts(statistics: [(String, Int)]) -> [Int] {
//    var counts = [Int]()
//    for (name, count) in statistics where count > 0 {
//        counts.append(count)
//    }
//
//    return counts.sorted(by: >)
//}

let collectedCounts = counts(statistics: commitStats)
print(collectedCounts) // [650, 30]



//let commitsDict = [
//    "Miranda": 30,
//    "Elly": 650,
//    "John": 0
//]

print(commitStats) // [(name: "Miranda", count: 30), (name: "Elly", count: 650), (name: "John", count: 0)]
let commitsDict = Dictionary(uniqueKeysWithValues: commitStats)
print(commitsDict) // ["Miranda": 30, "Elly": 650, "John": 0]

let mappedKeysAndValues = commitsDict.map { (name: String, count: Int) -> String in
    switch count {
    case 0: return "\(name) is not involved in the project"
    case 1..<100: return "\(name) is not very active on the project"
    default: return "\(name) is active on the project"
    }
}

print(mappedKeysAndValues) // ["Miranda is not very active on the project", "Elly is active on the project", "John is not involved in the project"]

let mappedValues = commitsDict.mapValues { (count: Int) -> String in
    switch count {
    case 0: return "Not involved in the project"
    case 1..<100: return "Not very active on the project"
    default: return "Is active on the project"
    }
}

//: ## Mapping over dictionaries
print(mappedValues) // ["Miranda": "Very active on the project", "Elly": "Is active on the project", "John": "Not involved in the project"]


//___________________________________________________________________


import Foundation

//: # Mapping over sequences

let names = [
    "John",
    "Mary",
    "Elizabeth"
]
let nameCount = names.count

let generatedNames = (0..<5).map { index in
    return names[index % nameCount]
}

print(generatedNames) // ["John", "Mary", "Elizabeth", "John", "Mary"]


//___________________________________________________________________


import Foundation
import UIKit

//: # Mapping over optionals

//: Removing emojis from a string.

/// Removed emoji from a string
///
/// - Parameter string: a target string to filter emoji's from
/// - Returns: The string without emoji's
func removeEmojis(_ string: String) -> String {
     var scalars = string.unicodeScalars
     scalars.removeAll(where: { $0.properties.isEmoji })
     return String(scalars)
}

//: ## Cover without map

class Cover {
    let image: UIImage
    let title: String?

    init(image: UIImage, title: String?) {
        self.image = image

        var cleanedTitle: String? = nil
        if let title = title {
            cleanedTitle = removeEmojis(title)
        }
        self.title = cleanedTitle
    }
}

//: ## Cover with elaborate map

//struct Cover {
//    let image: UIImage
//    let title: String?
//
//    init(image: UIImage, title: String?) {
//        self.image = image
//
//        self.title = title.map { (string: String) -> String in
//            return removeEmojis(string)
//        }
//    }
//}

//: ## Cover with short map

//struct Cover {
//    let image: UIImage
//    let title: String?
//
//    init(image: UIImage, title: String?) {
//        self.image = image
//        self.title = title.map(removeEmojis)
//    }
//}

//: ## Cover with two mapping operations chained

//struct Cover {
//    let image: UIImage
//    let title: String?
//
//    init(image: UIImage, title: String?) {
//        self.image = image
//        self.title =
//            title
//                .map(removeEmojis)
//                .map { $0.trimmingCharacters(in: .whitespaces) }
//    }
//}
//
let image = UIImage()
let cover = Cover(image: image, title: "❤️ OMG Cute ⭐️⭐️babypics⭐️⭐️! 😍❤️🍼👶")
print(cover.title) // Optional("OMG Cute babypics!")

print(removeEmojis("Hi💩😬🎉🐑🚙✋😇😴🚁🛀")) // "Hi"



//___________________________________________________________________



import Foundation

//: # Optional flatMap

//: ## Double-nested optional
//: When mapping over an string to turn it into a url, we end up with a double-nested optional.

//
//let receivedData = ["url" : "https://www.clubpenguinisland.com"]
//
//let path: String? = receivedData["url"]
//
//let url = path.map { (string: String) -> URL? in
//    let url = URL(string: string) // Optional(https://www.clubpenguinisland.com)
//    return url // We return an optional string
//}
//
//print(url) // Optional(Optional(http://www.clubpenguinisland.com))

//: ## Removing double-nesting with a force unwrap
//: When mapping over an string to turn it into a url, we end up with a double-nested optional. We can prevent this with a force unwrap, but doing this is crash-sensitive!
//
//let receivedData = ["url" : "https://www.clubpenguinisland.com"]
//
//let path: String? = receivedData["url"]
//
//let url = path.map { (string: String) -> URL in
//    return URL(string: string)! // We force unwrap, dangerous!
//}
//
//print(url) // Optional(http://www.clubpenguinisland.com)

//: ## Removing double-nesting with flatMap
//: We can safely remove double-nested optionals with flatMap

let receivedData = ["url" : "https://www.clubpenguinisland.com"]

let path: String? = receivedData["url"]

let url = path.flatMap { (string: String) -> URL? in // We return URL? again
    return URL(string: string) // We return an optional URL
}

print(url) // Optional(http://www.clubpenguinisland.com) // The optional is not double-nested


//___________________________________________________________________



import Foundation


/// Removed emoji from a string
///
/// - Parameter string: a target string to filter emoji's from
/// - Returns: The string without emoji's
func removeEmojis(_ string: String) -> String {
     var scalars = string.unicodeScalars
     scalars.removeAll(where: { $0.properties.isEmoji })
     return String(scalars)
}
//: Map works on multiple types

let omgBabies: String? = "❤️ OMG Cute ⭐️⭐️babypics⭐️⭐️! 😍❤️🍼👶"
print(omgBabies.map(removeEmojis)) // Optional(" OMG Cute babypics! ")

let food = ["Favorite Meal": "🍕 Pizza", "Favorite Drink": "☕️ Coffee"]
print(food.mapValues(removeEmojis)) // ["Favorite Meal": " Pizza", "Favorite Drink": " Coffee"]

let set: Set<String> = ["Great job 👍🏻", "Excellent 🙌"]
print(set.map(removeEmojis)) // ["Great job ", "Great job "]

//    let
//.mapValues(removeEmojis)
//[1000: "Some value"].mapValues(removeEmojis)


//___________________________________________________________________


import Foundation

//: # Pyramid of doom

func half(_ int: Int) -> Int? { // Only half even numbers
    guard int % 2 == 0 else { return nil }
    return int / 2
}
print(half(4)) // Optional(2)
print(half(5)) // nil

var value: Int? = nil
let startValue = 80

//: We can continuously unwrap optional operations, ending up with a pyramid of domo.

if let halvedValue = half(startValue) {
    print(halvedValue) // 40
    value = halvedValue
    
    if let halvedValue = half(halvedValue) {
        print(halvedValue) // 20
        value = halvedValue
        
        if let halvedValue = half(halvedValue) {
            print(halvedValue) // 10
            if let halvedValue = half(halvedValue) {
                value = halvedValue
            } else {
                value = nil
            }
            
        } else {
            value = nil
        }
    } else {
        value = nil
    }
}

print(value) // Optional(5)

//: A pyramid of doom can be prevented when stacking if let unwraps.

var endValue: Int? = nil

if
    let firstHalf = half(startValue),
    let secondHalf = half(firstHalf),
    let thirdHalf = half(secondHalf),
    let fourthHalf = half(thirdHalf) {
    endValue = fourthHalf
}
print(endValue) // Optional(5)

//: But, alternatively we can use flatMap, which is useful when we don't have clean one-liner functions to use in if-let statements. Also we don't have to bind new constants.

let endResult =
    half(startValue)
        .flatMap(half)
        .flatMap(half)
        .flatMap(half)

print(endResult) // Optional(5)


//___________________________________________________________________



import Foundation

//: # flatMapping over collections

//: We can create a new array inside flatMap, which will instantly be flattened.

let repeated = [2, 3].flatMap { (value: Int) -> [Int] in
    return [value, value]
}

print(repeated) // [2, 2, 3, 3]

//: We can flatten an existed nested array with flatMap, if we don't perform any actions inside the flatMap closure.

let stringsArr = [["I", "just"], ["want", "to"], ["learn", "about"], ["protocols"]]
let flattenedArray = stringsArr.flatMap { $0 }
print(flattenedArray) // ["I", "just", "want", "to", "learn", "about", "protocols"]


//: Strings are collections, which can also be flatMapped.

extension String {
    func interspersed(_ element: Character) -> String {
        let characters = self.flatMap { return [$0, element] }.dropLast()
        return String(characters)
    }
}

let interspersedString = "Swift".interspersed("-")
print(interspersedString) // S-w-i-f-t


//: You can combine all values of two sequences with flatMap and map.

let suits = ["Hearts", "Clubs", "Diamonds", "Spades"]
let faces = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]

var deckOfCards = suits.flatMap { suit in
    faces.map { face in
        (suit, face)
    }
}
deckOfCards.shuffle()
print(deckOfCards) // [("Diamonds", "5"), ("Hearts", "8"), ("Hearts", "K"), ("Clubs", "3"), ("Diamonds", "10"), ("Spades", "A"), ...


//___________________________________________________________________



import Foundation

//: # compactMap


let wrongUrl = URL(string: "OMG SHOES")
print(wrongUrl) // nil
let properUrl = URL(string: "https://www.swift.org")
print(properUrl) // Optional(https://www.swift.org)

let strings = [
    "https://www.duckduckgo.com",
    "https://www.twitter.com",
    "OMG SHOES",
    "https://www.swift.org"
]

//: Notice how compactMap filters out "OMG SHOES", and no values are optional
//let optionalUrls = strings.map { URL(string: $0) }
//print(optionalUrls) // [Optional(https://www.duckduckgo.com), Optional(https://www.twitter.com), nil, Optional(https://www.swift.org)]
let urls = strings.compactMap(URL.init)
print(urls) // [https://www.duckduckgo.com, https://www.twitter.com, https://www.swift.org]

//: If you don't like compactMap, you can use a for loop

let optionalUrls: [URL?] = [
    URL(string: "https://www.duckduckgo.com"),
    URL(string: "Bananaphone"),
    URL(string: "https://www.twitter.com"),
    URL(string: "https://www.swift.org")
]
for case let url? in optionalUrls {
    print("The url is \(url)") // url is unwrapped here
}

//: flatMap can be either chained or nested.
func half(_ int: Int) -> Int? { // Only half even numbers
    guard int % 2 == 0 else { return nil }
    return int / 2
}

let value = Optional(40)
let lhs = value.flatMap(half).flatMap(half)
let rhs = value.flatMap { int in half(int).flatMap(half) }
lhs == rhs // true
print(rhs) // Optional(10)

//: You can nest flatMaps for special operations.

let string = "abc"
let results = string.flatMap { a -> [(Character, Character)] in
    string.compactMap { b -> (Character, Character)? in
        if a == b {
            return nil
        } else {
            return (a, b)
        }
    }
}
print(results) // [("a", "b"), ("a", "c"), ("b", "a"), ("b", "c"), ("c", "a"), ("c", "b")]


//___________________________________________________________________

