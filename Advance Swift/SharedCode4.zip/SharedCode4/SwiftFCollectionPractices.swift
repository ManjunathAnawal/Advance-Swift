

 # Iterators, Sequences, and Collections
 
//___________________________________________________________________

PLEASE TRY ONE EXAMPLE AT A TIME
THIS IS CUMMULATIVE FILE OF ALL EXAMPLES
EXAMPLES ARE SEPERATED WITH FOLLOWING SEPERATOR LINE

//___________________________________________________________________

 
//___________________________________________________________________


//: # IteratorProtocol

let cheeses = ["Gouda", "Camembert", "Brie"]

for cheese in cheeses {
    print(cheese)
}

var cheeseIterator = cheeses.makeIterator()

while let cheese = cheeseIterator.next() {
    print(cheese)
}

// Prints:
//"Gouda"
//"Camembert"
//"Brie"

//
//for element in values {
//    // do something with character
//}

// Under the hood

// Taking a closer look at iterator

let groceries = ["Flour", "Eggs", "Sugar"]
var groceriesIterator: IndexingIterator<[String]> = groceries.makeIterator()
print(groceriesIterator.next()) // Optional("Flour")
print(groceriesIterator.next()) // Optional("Eggs")
print(groceriesIterator.next()) // Optional("Sugar")
print(groceriesIterator.next()) // nil
print(groceriesIterator.next()) // nil

//print(iterator.next()) // Optional("a")
//print(iterator.next()) // Optional("b")
//print(iterator.next()) // Optional("c")
//print(iterator.next()) // nil
//print(iterator.next()) // nil


//___________________________________________________________________


import Foundation

//: # Useful methods on Sequence

//: ## forEach

["file_one.txt", "file_two.txt"].forEach { path in
    deleteFile(path: path)
}

["file_one.txt", "file_two.txt"].forEach(deleteFile)

func deleteFile(path: String) {
    // deleting file ....
}

//: ## enumerated

["First line", "Second line", "Third line"]
    .enumerated()
    .forEach { (index: Int, element: String) in
        print("\(index+1): \(element)")
}

//: ## Lazy

let bigRange = 0..<Int.max

let filtered = bigRange.lazy.filter { (int) -> Bool in
    return int % 2 == 0
}

// We want the last three elements. But still, nothing happens yet
let lastThree = filtered.suffix(3)

// Now the lazy code is evaluated
for value in lastThree {
    print(value) // values are consumed
}

//: ## Reduce

let text = "It's hard to come up with fresh exercises.\nOver and over again.'\nAnd again."
let startValue = 0
let numberOfLineBreaks = text.reduce(startValue) { (accumulation: Int, char: Character) in
    if char == "\n" {
        return accumulation + 1
    } else {
        return accumulation
    }
}

print(numberOfLineBreaks) // 2

//: ## Reduce into

let grades = [3.2, 4.2, 2.6, 4.1]
let slowResults = grades.reduce([:]) { (results: [Character: Int], grade: Double) in
    var copy = results
    switch grade {
    case 1..<2: copy["D", default: 0] += 1
    case 2..<3: copy["C", default: 0] += 1
    case 3..<4: copy["B", default: 0] += 1
    case 4...: copy["A", default: 0] += 1
    default: break
    }
    
    return copy
}

print(slowResults) // ["C": 1, "B": 1, "A": 2]

let results = grades.reduce(into: [:]) { (results: inout [Character: Int], grade: Double) in
    switch grade {
    case 1..<2: results["D", default: 0] += 1
    case 2..<3: results["C", default: 0] += 1
    case 3..<4: results["B", default: 0] += 1
    case 4...: results["A", default: 0] += 1
    default: break
    }
}

print(results) // ["C": 1, "B": 1, "A": 2]

//: ## zip
for (integer, string) in zip(0..<10, ["a", "b", "c"]) {
    print("\(integer): \(string)")
}
// Output:
// 0: a
// 1: b
// 2: c


//___________________________________________________________________


struct Bag<T: Hashable> {
    private var store = [T: Int]()
    
    mutating func insert(_ element: T) {
        store[element, default: 0] += 1
    }
    
    mutating func remove(_ element: T) {
        store[element]? -= 1
        if store[element] == 0 {
            store[element] = nil
        }
    }
    
    var count: Int {
        return store.values.reduce(0, +)
    }
    
}

extension Bag: CustomStringConvertible {
    var description: String {
        var summary = String()
        for (key, value) in store {
            let times = value == 1 ? "time" : "times"
            summary.append("\(key) occurs \(value) \(times)\n")
        }
        return summary
    }
}

var bag = Bag<String>()
bag.insert("Huey")
bag.insert("Huey")
bag.insert("Huey")

bag.insert("Mickey")

bag.remove("Huey")

bag.count // 3
print(bag)
//Output:
//Huey occurs 2 times
//Mickey occurs 1 time


//: ## Making Bag conform to Sequence

struct BagIterator<T: Hashable>: IteratorProtocol {
    
    var store = [T: Int]()
    
    mutating func next() -> T? {
        guard let (key, value) = store.first  else {
            return nil
        }
        if value > 1 {
            store[key]? -= 1
        } else {
            store[key] = nil
        }
        return key
    }
}

extension Bag: Sequence {
    func makeIterator() -> BagIterator<T> {
        return BagIterator(store: store)
    }
}

//: Alternatively, we can use AnyIterator

//extension Bag: Sequence {
//    func makeIterator() -> AnyIterator<T> {
//        var exhaustiveStore = store // create copy
//
//        return AnyIterator<T> {
//            guard let (key, value) = exhaustiveStore.first  else {
//                return nil
//            }
//            if value > 1 {
//                exhaustiveStore[key]? -= 1
//            } else {
//                exhaustiveStore[key] = nil
//            }
//            return key
//        }
//    }
//}

// Now we can call forEach, filter etc

bag.filter { $0.count > 2}
bag.contains("Huey") // true
bag.contains("Mickey") // false

//: ## ExpressibleByArrayLiteral

extension Bag: ExpressibleByArrayLiteral {
    typealias ArrayLiteralElement = T
    init(arrayLiteral elements: T...) {
        store = elements.reduce(into: [T: Int]()) { (updatingStore, element) in
            updatingStore[element, default: 0] += 1
        }
    }
}

let anotherBag: Bag = [1.0, 2.0, 2.0, 3.0, 3.0, 3.0]
print(anotherBag)
// Output:
// 2.0 occurs 2 times
// 1.0 occurs 1 time
// 3.0 occurs 3 times

let colors: Bag = ["Green", "Green", "Blue", "Yellow", "Yellow", "Yellow"]
print(colors)
// Output:
// Green occurs 2 times
// Blue occurs 1 time
// Yellow occurs 3 times


//___________________________________________________________________


//: # Useful methods for collections

import Foundation

//: # Collection

let strayanAnimals = "Kangaroo Koala"
if let middleIndex = strayanAnimals.firstIndex(of: " ") {
    strayanAnimals.prefix(upTo: middleIndex) // Kangaroo
    strayanAnimals.suffix(from: strayanAnimals.index(after: middleIndex)) // Koala
}

//: # MutableCollection

var mutableArray = [4,3,1,2]
mutableArray.sort() // [1, 2, 3, 4]

var arr = [1,2,3,4,5]
let partitioned = arr.partition { (int) -> Bool in
    return int % 2 == 0
}

print(partitioned) // 3
print(arr) // [1, 5, 3, 4, 2]

arr[..<partitioned] // [1, 5, 3]
arr[partitioned...] // [4, 2]

// With MutableCollection we can sort in place
var evens: ArraySlice<Int> = arr[partitioned...] // [4, 2]
evens.sort() // [2, 4]

//: ## RangeReplaceableCollection

var muppets = ["Kermit", "Miss Piggy", "Fozzie bear"]

muppets += ["Statler", "Waldorf"]
print(muppets) // ["Kermit", "Miss Piggy", "Fozzie bear", "Statler", "Waldorf"]

muppets.removeFirst() // "Kermit"
print(muppets) // ["Miss Piggy", "Fozzie bear", "Statler", "Waldorf"]

muppets.removeSubrange(0..<2)
print(muppets) // ["Statler", "Waldorf"]

var matrix = "The Matrix"
matrix += " Reloaded"
print(matrix) // The Matrix Reloaded

//: RangeReplaceableCollection also offers mutating func removeAll(where shouldBeRemoved: (Element) throws -> Bool) rethrows

var healthyFood = ["Donut", "Lettuce", "Kiwi", "Grapes"]
healthyFood.removeAll(where:{ $0 == "Donut" })
print(healthyFood) // ["Lettuce", "Kiwi", "Grapes"]

//: ## BidirectionalCollection

var letters = "abcd"
var lastIndex = letters.endIndex

while lastIndex > letters.startIndex {
    lastIndex = letters.index(before: lastIndex)
    print(letters[lastIndex])
}

// Output:
// d
// c
// b
// a

//: Alternatively, we can use reversed.

for value in letters.reversed() {
    print(value)
}


//: ## RandomAccessCollection

//: Distance lookups are in constant-time.

["a", "b", "c", "d"].distance(from: 1, to: 4) // 3
["a", "b", "c", "d"].index(1, offsetBy: 2, limitedBy: 0) // 3

//: A Repeated type is a RandomAccessCollection
for element in repeatElement("Broken record", count: 3) {
    print(element)
}

// Output:
// Broken record
// Broken record
// Broken record

zip(repeatElement("Mr. Sniffles", count: 3), repeatElement(100, count: 3)).forEach { name, index in
    print("Generated \(name) \(index)")
}


//___________________________________________________________________


import Foundation
import Foundation

struct Activity: Equatable {
    let date: Date
    let description: String
}

struct Day: Hashable {
    let date: Date
    
    init(date: Date) {
        // Strip time from Date
        let unitFlags: Set<Calendar.Component> = [.day, .month, .year]
        let components = Calendar.current.dateComponents(unitFlags, from: date)
        guard let convertedDate = Calendar.current.date(from: components) else {
            self.date = date
            return
        }
        self.date = convertedDate
    }
    
}

struct TravelPlan {
    
    typealias DataType = [Day: [Activity]]
    
    private var trips = DataType()
    
    init(activities: [Activity]) {
        self.trips = Dictionary(grouping: activities) { activity -> Day in
            Day(date: activity.date)
        }
    }
    
}

extension TravelPlan: Collection {
    
    typealias KeysIndex = DataType.Index
    typealias DataElement = DataType.Element
    
    var startIndex: KeysIndex { return trips.startIndex }
    var endIndex: KeysIndex { return trips.endIndex }
    func index(after i: KeysIndex) -> KeysIndex {
        return trips.index(after: i)
    }
    
    subscript(index: KeysIndex) -> DataElement {
        return trips[index]
    }
    
}
//: We can now iterate over TravelPlan

let activities = [
    Activity(date: Date(), description: "Hiking"),
    Activity(date: Date(), description: "Lunch break"),
    Activity(date: Date(), description: "Mountain biking"),
    Activity(date: Date(), description: "Kayaking")
]

let travelPlan = TravelPlan(activities: activities)

for (day, activities) in travelPlan {
    print(day)
    print(activities)
}


// We get a default iterator, no need to create one ourselves.
let defaultIterator: IndexingIterator<TravelPlan> = travelPlan.makeIterator()

//: Add Bonus subscript for syntactic sugar

extension TravelPlan {
    subscript(date: Date) -> [Activity] {
        return trips[Day(date: date)] ?? []
    }
    
    subscript(day: Day) -> [Activity] {
        return trips[day] ?? []
    }
}

let day = Day(date: Date())
travelPlan[day]
travelPlan[Date()]

extension TravelPlan: ExpressibleByArrayLiteral {
    init(arrayLiteral elements: Activity...) {
        self.init(activities: elements)
    }
}

extension TravelPlan: ExpressibleByDictionaryLiteral {
    init(dictionaryLiteral elements: (Day, [Activity])...) {
        self.trips = Dictionary(elements, uniquingKeysWith: { (first, _) in
            return first
        })
    }
}

let adrenalineTrip = Day(date: Date())
let adrenalineActivities = [
    Activity(date: Date(), description: "Bungee jumping"),
    Activity(date: Date(), description: "Driving in rush hour LA"),
    Activity(date: Date(), description: "Sky diving")
]

let adrenalinePlan: TravelPlan = [adrenalineTrip: activities] // We can now create a TravelPlan from a dictionary


//___________________________________________________________________


