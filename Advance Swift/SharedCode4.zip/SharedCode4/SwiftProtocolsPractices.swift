
import Foundation

//_________________________________________________________

// SOLID
// 

// Protocol Oriented Programming
//		Protocol Driven Programming

// In Mathematics
// 		Design Towards Abstract Type Rather Than Concrete Type
// 			Design Towards Interfaces/Protocols Rather Than Concrete Classes

// In Mathematics
//		Abstract Type
//			Operation = { fly, saveWorld }
//			Range     = Phi Set
protocol Superpower {
	func fly() 		 
	func saveWorld()
}

class Spiderman: Superpower {
	func fly() 		 { print("Fly Like Spiderman!") }
	func saveWorld() { print("SaveWorld Like Spiderman!") }
} 

class Superman : Superpower {
	func fly() 		 { print("Fly Like Superman!") }
	func saveWorld() { print("SaveWorld Like Superman!") }
} 

class Heman : Superpower {
	func fly() 		 { print("Fly Like Heman!") }
	func saveWorld() { print("SaveWorld Like Heman!") }
} 

class WonderWoman: Superpower {
	func fly() 		 { print("Fly Like WonderWoman!") }
	func saveWorld() { print("SaveWorld Like WonderWoman!") }	
}

// Using Inheritance 
// class Human : BadHeman {
// 	override func fly() 		 { super.fly() }
// 	override func saveWorld() { super.saveWorld() }
// }

// Composition Design Pattern
//		Delegation
// Human Is Polymorphic
class Human {
	// Here power Is Delegate and It Conforms To Superpower Protocol
	var power: Superpower?
	func fly() 			{ power?.fly() }
	func saveWorld() 	{ power?.saveWorld() }
}
 
var human = Human()
human.power = Spiderman()
human.fly()
human.saveWorld()

human.power = Superman()
human.fly()
human.saveWorld()

// human.power = BadHeman()
// human.fly()
// human.saveWorld()

human.power = Heman()
human.fly()
human.saveWorld()

human.power = WonderWoman()
human.fly()
human.saveWorld()


// class TableViewController {
// 	// Here power Is Delegate and It Conforms To Superpower Protocol
// 	var delegate: De?
// 	var dataSource: DataSourceProtocol

// 	func fly() 			{ power?.fly() }
// 	func saveWorld() 	{ power?.saveWorld() }
// }

//_________________________________________________________

/*

import Foundation

protocol CryptoCurrency {
    var name: String { get }
    var symbol: String { get }
    var holdings: Double { get set }
    var price: NSDecimalNumber? { get set }
}

struct Bitcoin: CryptoCurrency {
    let name = "Bitcoin"
    let symbol = "BTC"
    var holdings: Double
    var price: NSDecimalNumber?
}

struct Ethereum: CryptoCurrency {
    let name = "Ethereum"
    let symbol = "ETH"
    var holdings: Double
    var price: NSDecimalNumber?
}

final class Portfolio<Coin: CryptoCurrency> {
    var coins: [Coin]
    
    init(coins: [Coin]) {
        self.coins = coins
    }
    
    func addCoin(_ newCoin: Coin) {
        coins.append(newCoin)
    }
    
    func calculateSum() -> NSDecimalNumber {
        var value = NSDecimalNumber(value: 0)
        for coin in coins {
            let amount = coin.holdings * (coin.price?.doubleValue ?? 0)
            value = value.adding(NSDecimalNumber(value: amount))
        }
        return value
    }
}

let coins = [
    Ethereum(holdings: 4, price: NSDecimalNumber(value: 500)),
    // Bitcoin(holdings: 4, price: NSDecimalNumber(value: 6000)) // We can't mix
]

let portfolio = Portfolio(coins: coins)

// portfolio.addCoin(Bitcoin())
//  error: cannot convert value of type 'Bitcoin' to expected argument type 'Ethereum'
print(type(of: portfolio.coins)) // Array<Ethereum>

*/

//_________________________________________________________

class Person { }

class Employee: Person { }

class Manager: Person { }

class Student: Person { }

let dataArray : [Person] = [ Employee(), Manager(), Student() ]

let dataArrayAgain: [Any] = [10, 20, 90.90, "Ding"]


//_________________________________________________________


import Foundation

protocol CryptoCurrency {
    var name: String { get }
    var symbol: String { get }
    var holdings: Double { get set }
    var price: NSDecimalNumber? { get set }
}

struct Bitcoin: CryptoCurrency {
    let name = "Bitcoin"
    let symbol = "BTC"
    var holdings: Double
    var price: NSDecimalNumber?
}

struct Ethereum: CryptoCurrency {
    let name = "Ethereum"
    let symbol = "ETH"
    var holdings: Double
    var price: NSDecimalNumber?
}

final class Portfolio {
    var coins: [CryptoCurrency]
    
    init(coins: [CryptoCurrency]) {
        self.coins = coins
    }
    
    func addCoin(_ newCoin: CryptoCurrency) {
        coins.append(newCoin)
    }
    
    // Helper functions as an example. E.g. we could calculate total value.
    func calculateSum() -> NSDecimalNumber {
        var value = NSDecimalNumber(value: 0)
        for coin in coins {
            let amount = coin.holdings * (coin.price?.doubleValue ?? 0)
            value = value.adding(NSDecimalNumber(value: amount))
        }
        return value
    }
}

//: No need to specify what goes inside of portfolio.
let portfolio = Portfolio(coins: [])

//: Now we can mix coins.
let coins: [CryptoCurrency] = [
    Ethereum(holdings: 4, price: NSDecimalNumber(value: 500)),
    Bitcoin(holdings: 4, price: NSDecimalNumber(value: 6000))
]

portfolio.coins = coins

print(type(of: portfolio)) // Portfolio
let retrievedCoins = portfolio.coins
print(type(of: retrievedCoins)) // Array<CryptoCurrency>


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
