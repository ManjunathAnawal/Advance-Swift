
var some = 10

func doSomething() { // Context
	let something = some + 100
}

{   // L
	{ // L1
		{ //L11

		}
		
		{ // L12

		}
	}
	
	{ // L2
		{ // L21

		}
		
		{ // L22

		}
	}
}

