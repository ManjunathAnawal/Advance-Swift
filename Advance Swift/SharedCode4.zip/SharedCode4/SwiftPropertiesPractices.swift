
import Foundation

//_________________________________________________________

struct Run {
	let id: String
	let startTime: Date
	var endTime: Date?

	init(id: String, startTime: Date) {
		self.id = id
		self.startTime = startTime
		self.endTime = nil
	}

	func elapsedTime() -> TimeInterval {
		return Date().timeIntervalSince( startTime )
	}

	func isFinished() -> Bool {
		return endTime != nil
	}

	// Swift Desinged Towards Immutability Rather Than Mutability
	//		Mutability Is Not Default
	mutating func settFinished() {
		endTime = Date()
	}
}

var run = Run( id: "100", startTime: Date() )

print( run.elapsedTime() )
print( run.isFinished() )
run.settFinished()
print( run.elapsedTime() )


//_________________________________________________________

struct RunAgain {
	// Stored Properties i.e. Storage Will Be Allocated
	let id: String
	let startTime: Date
	var endTime: Date?

	init(id: String, startTime: Date) {
		self.id = id
		self.startTime = startTime
		self.endTime = nil
	}

	// Computed Properties i.e. Storage Will NOT Be Allocated
	//		Value Of Computed Properties Will Be Calculated Everytime You Access It!
	var elapsedTime: TimeInterval {
		return Date().timeIntervalSince( startTime )
	}

	var isFinished: Bool {
		return endTime != nil
	}

	// Swift Desinged Towards Immutability Rather Than Mutability
	//		Mutability Is Not Default
	mutating func settFinished() {
		endTime = Date()
	}
}

var run1 = RunAgain( id: "100", startTime: Date() )
print( run1.elapsedTime )
print( run1.isFinished )
run1.settFinished()
print( run1.elapsedTime )

//_________________________________________________________

struct RunAgain1 {
	// Stored Properties i.e. Storage Will Be Allocated
	let id: String
	let startTime: Date
	var endTime: Date?

	init(id: String, startTime: Date) {
		self.id = id
		self.startTime = startTime
		self.endTime = nil
	}

	// Computed Properties i.e. Storage Will NOT Be Allocated
	//		Value Of Computed Properties Will Be Calculated Everytime You Access It!
	var elapsedTime: TimeInterval {
		return Date().timeIntervalSince( startTime )
	}

	var isFinished: Bool {
		get {
			return endTime != nil
		}
		set {
			if !newValue {
				endTime = nil
			} else if endTime == nil {
				endTime = Date()
			}
		}
	}

	// Swift Desinged Towards Immutability Rather Than Mutability
	//		Mutability Is Not Default
	// mutating func settFinished() {
	// 	endTime = Date()
	// }
}

var run2 = RunAgain1( id: "100", startTime: Date() )
print( run2.elapsedTime )
print( run2.isFinished )  // Will Call Getter Of Computed Propterty
run2.isFinished = true 
print( run2.endTime! )
print( run2.elapsedTime )

run2.isFinished = false // Will Call Setter Of Computed Propterty 
// print( run2.endTime )

//_________________________________________________________

struct LearningPlan {
	let level: Int
	var description: String

	var contents: String {
		print("Calculating stuff...")

		// sleep(2) // Calculations Taking Time...
		switch level {
		case ..<25: return "Do Life Check!..."
		case ..<50: return "Do Life Check Again..."
		case 100...: return "Before Life Check... Do health Check..."
		default: return "Hit Default Life!... Not Exciting At All :("
		}
	}
}


var plan = LearningPlan(level: 10, description: "Special Learning Plan...")
print( plan.contents )

print( Date() )

for _ in 0..<5 {
	print( plan.contents )
}
print( Date() )

//_________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE RAISE YOUR HAND!!!
struct LearningPlan1 {
	var level: Int // = 10
	var description: String // = "Hello World!"

	// Lazy Property Will Be Initialised Lazily
	//		Will Be Accessed On Demand
	//		Will Be Calculated Only Once and Stored Value and Than It Will Be Reused
	// error: 'lazy' cannot be used on a let
	// Mutable Lazy Properties Can Have Side Effects Make It Robust
	lazy private(set) var contents: String = {
		print("Calculating stuff...")

		sleep(2) // Calculations Taking Time...

		switch level {
		case ..<25: return "Do Life Check!..."
		case ..<50: return "Do Life Check Again..."
		case 100...: return "Before Life Check... Do health Check..."
		default: return "Hit Default Life!... Not Exciting At All :("
		}
	}() // Closure Invocation

	init( level: Int, description: String) {
		self.level = level
		self.description = description
	}
}

// ASSIGNMENT : HOME WORK...
// DESIGN QUESTION
//		MAKE FOLLOWING ORDER AGNOSTIC
var intensePlan = LearningPlan1(level: 40, description: "Special Learning Plan...")

var easyPlan = intensePlan
easyPlan.level = 0

// plan1.contents = "Something Different... Not Part of The Plan Happened..."
print( Date() )
for _ in 0..<5 {
	print( intensePlan.contents )
}
print( Date() )

print( intensePlan.contents )
print( intensePlan.level )


print(easyPlan.contents )
print(easyPlan.level)

print( intensePlan.contents )
print( intensePlan.level )

// Do Life Check Again...
// 40
// Do Life Check Again...
// 0
// Do Life Check Again...
// 40

//_________________________________________________________

// BEST PRACTICE
//		Object Initialisation Must Be Consistent 
//		Across All Initialisation Mechanisms

class Player {
	let id : String

	var name : String {
		willSet { // Property Observers
			print("name property willSet Called...")
		}
		// set {
		// 	name = newValue
		// 	print("name property SETTER Called...")		
		// }
		didSet { // Property Observers
			print("name property didSet Called...")
			name = name.trimmingCharacters( in: .whitespaces )
		}
	}

	init( id: String, name: String ) {
		defer { self.name = name } // This Will Invoke Setter
		self.id = id
		self.name = name // This Will Not Invoke Setter
	}
}

let tom = Player(id: "100", name: "Tom Harris   ")
print(tom.name)
print(tom.name.count)

tom.name = "Tom Harris   " // Invoke Property Setter
print(tom.name)
print(tom.name.count)

// Tom Harris   
// 13
// Tom Harris
// 10

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

// Once you initialize a lazy property, you cannot change it. You need to use extra caution when you use mutable properties—also known as var properties—in combination with lazy properties. This holds even truer when working with structs.


