
import Foundation

print("Hello World!!!")

// ASCII Character <----> ASCII CDOE It's 1:1 Mapping
// Unicode Characters
// Unicode Character <----> Multiple Unicode Points. It's 1:N Mapping

let eAcuteQuestion = "Voulez-vous un caf\u{E9}?"

let combinedEAcuteQuestion = "Voulez-vous un caf\u{65}\u{301}?"
let combinedEAcuteQuestion2 = "Voulez-vous un cafe\u{301}?"

print(eAcuteQuestion)
print(combinedEAcuteQuestion)
print(combinedEAcuteQuestion2)

if eAcuteQuestion == combinedEAcuteQuestion {
    print("These two strings are considered equal")
}

if eAcuteQuestion == combinedEAcuteQuestion2 {
    print("These two strings are considered equal")
}

// __________________________________________________

let approximateCount = 62
var naturalCount: String 

// Switch Is Type Safe In Swift
switch approximateCount {
case 0:
	naturalCount = "No"
case 1..<5:
	naturalCount = "Ding"
case 5..<100:
	naturalCount = "Dong"
//case 101...naturalCount.max:
//	naturalCount = "Ting"
//	SwiftBasics.swift:32:1: error: switch must be exhaustive
case _:
	naturalCount = "Ting"
}

// __________________________________________________

// Swift switch Idioms
let somePoint = (1,1)
switch somePoint {
case (0, 0):
    print("(0,0) is at the origin")
case (_, 0):
    print("\(somePoint.0),0) is on the x-axis")
case (0, _):
    print("(0, \(somePoint.1)) is on the y-axis")
case (-2...2, -2...2):
    print("(\(somePoint.0), \(somePoint.1)) is inside the box")
default:
    print("(\(somePoint.0), \(somePoint.1)) is outside of the box")
}

// Value Bindings
let anotherPoint = (2, 0)
switch anotherPoint {
case (let x, 0):
    print("on the x-axis with an x value of \(x)")
case (0, let y):
    print("on the y-axis with a y value of \(y)")
case let (x, y):
    print("somewhare else at (\(x), \(y))")
}


// Where
let yetAnotherPoint = (1, -1)
switch yetAnotherPoint {
case let (x, y) where x == y:
    print("(\(x), \(y)) is on the line x == y")
case let (x, y) where x == -y:
    print("(\(x), \(y)) is on the line x == -y")
case let (x, y):
    print("(\(x), \(y)) is just some arbitrary point")
}


//_______________________________________________________

// Swifty Style API
func minMax( array: [Int] ) -> (min: Int, max: Int) {
	var currentMin = array[0]
	var currentMax = array[1]

	for value in array[1..<array.count] {
		if value < currentMin {
			currentMin = value
		} else if value > currentMax {
			currentMax = value 
		}
	}

	return (currentMin, currentMax)
}

let bounds = minMax( array: [10, 20, 30, -10, 100, 90])
print( bounds )

// ____________________________________________________

// Polymorphic Function
//		Mechanism : Using Default Arguments
func joinStrings( first: String, second: String, joiner: String = "  ") -> String {
	return first + joiner + second
}

print( joinStrings(first: "Ram", second: "Singh", joiner: " --- "))
print( joinStrings(first: "Ram", second: "Singh" ))

// __________________________________________________

// Polymorphic Function
//		Mechanism : Variadic Arguments
func artihmeticMean( numbers: Double... ) -> Double {
	var total: Double = 0.0
	for number in numbers {
		total += number
	}

	return total / Double( numbers.count )
}

print( artihmeticMean( numbers: 10, 20, 30, 40, 50))
print( artihmeticMean( numbers: 10, 100, 200 ))

// _________________________________________________

// EXPERIMENT FOLLOWING CODE, MOMENT DONE RAISE YOUR HAND!!!

// Higher Order Functions
//		Functions Which Takes Functions As Arguments
//			and/or
//		Return Functions


// SOLID Practices
// 		S - Single Responsibilty Design
//			Class/Functions Should Do One Thing and Well

//		O - Open-Close Principle
//			Classes/Functions Are Open For Extension and Closed For Modification

// Functions Are Objects Of Function Type

// Function Type
//		sun Is A Function Object Of Function Type (Int, Int) -> Int
func sum(x: Int, y: Int) -> Int {
	return x + y
}

// Function Type
//		sub Is A Function Object Of Function Type (Int, Int) -> Int
func sub(x: Int, y: Int) -> Int {
	return x - y
}

// Polymorphics Functions
//		Mechanism : Using Higher Order Function

//		O - Open-Close Principle
//			Clasess Are Open For Extension and Closed For Modification
func calculator(x: Int, y: Int, operation: (Int, Int) -> Int ) -> Int {
	return operation(x, y)
}

// Controller
func chooseOperation() {
	// Decisions Matrix
	// Based On User Input
	// Configure calculator Function
}


let x = 40
let y = 10
var result: Int

result = calculator(x: x, y: y, operation: sum)
print(result)

result = calculator(x: x, y: y, operation: sub)
print(result)

var doSomething: (Int, Int) -> Int  = sum
print( doSomething(100, 200) )

var doSomethingAgain: (Int, Int, (Int, Int) -> Int) -> Int = calculator
print( doSomethingAgain( 10, 20, sum) )


//________________________________________________________

// Higher Order Functions
//		Functions Which Takes Functions As Arguments
//			and/or
//		Return Functions

func stepForward( step: Int ) -> Int {
	return step + 1
}

func steoBackward( step: Int ) -> Int {
	return step - 1
}

func chooseStepFunction( forward: Bool ) -> (Int) -> Int {
	return forward ? stepForward : steoBackward
}

var doMagic : (Int) -> Int  = chooseStepFunction( forward: true )
var result1 = 10

result1 = doMagic(result1)
print( result1 )

result1 = doMagic(result1)
print( result1 )

result1 = doMagic(result1)
print( result1 )

doMagic = chooseStepFunction( forward: false )
result1 = 10

result1 = doMagic(result1)
print( result1 )

result1 = doMagic(result1)
print( result1 )

result1 = doMagic(result1)
print( result1 )


// _________________________________________________

// Higher Order Functions
//		Functions Which Takes Functions As Arguments
//			and
//		Return Functions


// BEST PRACTICE
//		Function Is Last Arguments


//class chooseStepFunctioAgain {
//	init ( start: Int, predicate: (Int) -> Bool ) -> (Int) -> Int { }

func chooseStepFunctioAgain( start: Int, predicate: (Int ) -> Bool ) -> (Int) -> Int {
	// Local Functions
	// 		Functions Defined Inside Function

	func stepForward( step: Int ) -> Int {
		return step + 1
	}

	func steoBackward( step: Int ) -> Int {
		return step - 1
	}

	return predicate(start) ? stepForward : steoBackward
}

func stepChoice( start : Int ) -> Bool {
	return start > 0 ? false : true
}

var doMagicAgain  = chooseStepFunctioAgain( start: 10, predicate: stepChoice )
result1 = 10

result1 = doMagicAgain(result1)
print( result1 )

result1 = doMagicAgain(result1)
print( result1 )

result1 = doMagicAgain(result1)
print( result1 )

// ___________________________________________________


func cookDoCoooking( cookItem: String, recipe: String? = nil ) {
	// Kitchen
	// Kitchen Items

	// Recipe To Cook

	// Process Of Cooking
}


func wifeOrderCooking(foodChoice: Bool) -> () -> (){
	let some = 10
	func pizzaRecipe() {
		let something = some + 100
		print(something)
	}

	func chillyManchurian() {

	}

	return foodChoice ? pizzaRecipe : chillyManchurian
}

func kidsOrderCooking(foodChoice: Bool) -> () -> () {
	func pizzaRecipe() {

	}

	func chillyManchurian() {

	}

	return foodChoice ? pizzaRecipe : chillyManchurian
}

// ___________________________________________________


// EXPERIMENT FOLLOWING CODE, MOMENT DONE RAISE YOUR HAND!!!

// Higher Order Functions
//		Functions Which Takes Functions As Arguments
//			and/or
//		Return Functions


// SOLID Practices
// 		S - Single Responsibilty Design
//			Class/Functions Should Do One Thing and Well

//		O - Open-Close Principle
//			Classes/Functions Are Open For Extension and Closed For Modification

// Function Type
//		sun Is A Function Object Of Function Type (Int, Int) -> Int

// In Mathematics It's Called Lambda and In Programming Languages Closure

// Function Type
//		sunClosure Have Function Type (Int, Int) -> Int

// Closures Are Objects Of Function Type

// Closure or Lamba Expression
let sumClosure = { (x: Int, y: Int) -> Int in return x + y }


// Function Type
//		subClosure Have Function Type (Int, Int) -> Int
// Closure or Lamba Expression
let subClosure = { (x: Int, y: Int) -> Int in 
	return x - y
}

// Polymorphics Functions
//		Mechanism : Using Higher Order Function
func calculatorAgain(x: Int, y: Int, operation: (Int, Int) -> Int ) -> Int {
	return operation(x, y)
}

// let x = 40
// let y = 10

result = calculatorAgain(x: x, y: y, operation: sumClosure)
print(result)

result = calculatorAgain(x: x, y: y, operation: subClosure)
print(result)

// ___________________________________________________

struct File {
	let file: String = ""
//	lazy let parser = Parser()

	
	func readFile() {
		print("Reading File...: \(file)")
	}

	init(file: String) {
		print("Initialising File Object.. with \(file)")
	}
}

struct FileManager {
	let manager = "File Manager..."
	lazy var file: File = File(file: "Data.txt")
	
	func downloadFile() {
		print( "Downloading File...")
	}
}

func playWithProperties() {
	var fileManager = FileManager()
	fileManager.downloadFile()
	print( fileManager.file )	
}

playWithProperties()

// Initialising File Object.. with Data.txt
// Downloading File...

// AFTER ADDING LAZY
// Downloading File...

// Downloading File...
// Initialising File Object.. with Data.txt
// File(file: "")

// ___________________________________________________
// ___________________________________________________
// ___________________________________________________
// ___________________________________________________
// ___________________________________________________
// ___________________________________________________
// ___________________________________________________
// ___________________________________________________
// ___________________________________________________
// ___________________________________________________
// ___________________________________________________

