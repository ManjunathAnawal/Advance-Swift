
// __________________________________________________________________________________
READING ASSIGNMENT

INT32-C. Ensure that operations on signed integers do not result in overflow
	https://wiki.sei.cmu.edu/confluence/display/c/INT32-C.+Ensure+that+operations+on+signed+integers+do+not+result+in+overflow

SWIFT INITIALISATION
    https://docs.swift.org/swift-book/LanguageGuide/Initialization.html


// __________________________________________________________________________________

>>>>	COMLETE CODING EXCERCISES 1 

>>>>	RAISE YOUR HANDS MOMENT YOU ARE DONE!!!!

// __________________________________________________________________________________
CODING ASSIGNMENT

 1. [Exercises](Exercises)
 
import Foundation

//: # Exercises

//: 1. Can you name two benefits of using subclassing over enums with associated types?
//: 2. Can you name two benefits of using enums with associated types over subclassing?
//: 3. What is the number of possible variations of Bagel?

enum Topping {
    case creamCheese
    case peanutButter
    case jam
}

enum BagelType {
    case cinnamonRaisin
    case glutenFree
    case oatMeal
    case blueberry
}

struct Bagel {
    let topping: Topping
    let type: BagelType
}

//: 4. Turn Bagel into an enum while keeping the same amount of possible variations.

//: 5. Given this enum representing a Puzzle game for a certain age range (baby, toddler etc) and containing a number of puzzle pieces.
//: How would could this enum be represented as a struct instead?
enum Puzzle {
    case baby(numberOfPieces: Int)
    case toddler(numberOfPieces: Int)
    case preschooler(numberOfPieces: Int)
    case gradeschooler(numberOfPieces: Int)
    case teenager(numberOfPieces: Int)
}


// __________________________________________________________________________________
// __________________________________________________________________________________
// __________________________________________________________________________________
CODING ASSIGNMENT


2. [Exercises](Exercises)

import Foundation

//: In this exercise we're modelling a music library. Think Apple Music or Spotify.

//: For now all that is important is that it allows us to turn raw data (such as plist files) into songs
struct Song: Decodable {
    let duration: Int
    let track: String
    let year: Int
}

struct Artist {
    var name: String
    var birthDate: Date
    var songsFileName: String
    
    init(name: String, birthDate: Date, songsFileName: String) {
        self.name = name
        self.birthDate = birthDate
        self.songsFileName = songsFileName
    }

    func getAge() -> Int? {
        let years = Calendar.current
            .dateComponents([.year], from: birthDate, to: Date())
            .year

        return years
    }
    
    func loadSongs() -> [Song] {
        guard
            let fileURL = Bundle.main.url(forResource: songsFileName, withExtension: "plist"),
            let data = try? Data(contentsOf: fileURL),
            let songs = try? PropertyListDecoder().decode([Song].self, from: data) else {
                return []
        }
        return songs
    }

    mutating func songsReleasedAfter(year: Int) -> [Song] {
        return loadSongs().filter { (song: Song) -> Bool in
            return song.year > year
        }
    }

}

//: 1. See if you can clean up the Artist type by using lazy and/or computed properties.

var components = DateComponents()
components.day = 4
components.month = 7
components.year = 1938
var billWithers = Artist(name: "Bill Withers", birthDate: Calendar.current.date(from: components)!, songsFileName: "songs")
billWithers.getAge()
let songs = billWithers.loadSongs()
print(billWithers.getAge())

//: 2. Assuming loadSongs is turned into a lazy property called "songs", make sure the following code doesn't break it by trying to override the property data
billWithers.songs = []

//: 3. Assuming loadSongs is turned into a lazy property called "songs", how can you make sure that the following lines won't break the lazily loaded property? Point out two ways to prevent a lazy property from breaking.
billWithers.songs
billWithers.songsFileName = "oldsongs" // change file name
billWithers.songs.count // Should be 0 after renaming songsFileName, but is 2

 //: 4. If you need a property with both behavior and storage, what kind of property would you use?
 //: 5. If you need a property with only behavior and no storage, what kind of property would you use?
 //: 6. Can you spot the bug in the code below?

import Foundation

struct Tweet {
    let date: Date
    let author: String
    var message: String {
        didSet {
            message = message.trimmingCharacters(in: .whitespaces)
        }
    }
}

let tweet = Tweet(date: Date(),
                  author: "@tjeerdintveen",
                  message: "This has a lot of unnecessary whitespace   ")

tweet.message.count

//: 7. How can you fix the bug?

// __________________________________________________________________________________
// __________________________________________________________________________________
// __________________________________________________________________________________
// __________________________________________________________________________________
