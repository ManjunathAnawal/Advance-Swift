
import Foundation

print("Hello!")

// DESIGN PRINCIPLE
//		Design Towards Immutability Rather Than Mutability	
//	

// IMMUTABLE Property
let maximumNumberOfLogins = 10

// MUTABLE
var currentLoginAttempts = 0

print( maximumNumberOfLogins )
print( currentLoginAttempts )


// Desinging Towards Immutability Rather Than Mutability
// Local Context Changes
//		Changes Are Happening In Some Function
// var maximumNumberOfLoginsLocal = maximumNumberOfLogins
// maximumNumberOfLoginsLocal = 90


// Type Of greeting???

//1. Type Inferrencing
//		Type Is Inferred From RHS. Value
//			i.e. "" Is String Type Value
//2. Type Binding
// 		LHS Identtifier Is Binded With Inferred Type
//		Compile Time Decision

let greeting = "Good Morning!"


//1. Type Inferrencing
//		Type Is Inferred From RHS. Value
//			i.e. "" Is String Type Value
//2. Type Conformance
// 		LHS Identtifier Type Conforms To Type As RHS Inferred Type


// Type Annotation
let greetingAgain: String = "Good Morning!"

// error: cannot convert value of type 'Int' to specified type 'String'
//  let greetingAgain1: String = 100


// In Java Following Is Possible
//		Implicit Type Conversion Happens from Int To String
// String greeting = 900;
//  "Hello World!" + 90;

print( greeting )
print( greetingAgain )


// _____________________________________________________________


//  WHAT IS A DATA TYPE OR TYPE ???
//

// Type Safe Language
// 		What Is Type Safety???
//		Never Violate Type Definition

//______________________________________________________________

let minValue = UInt8.min
let maxValue = UInt8.max

print(minValue)
print(maxValue)

//______________________________________________________________


let twoThoudand: UInt16 = 2000
let one: UInt8 = 1

// binary operator '+' cannot be applied to operands of type 'UInt16' and 'UInt8'
// let twoThoudandOne = twoThoudand + one
// print(twoThoudandOne)

let twoThoudandOne = twoThoudand + UInt16( one )
print(twoThoudandOne)

// Fatal error: Not enough bits to represent the passed value
// let twoThoudandOneAgain = UInt8( twoThoudand ) + one  
// print(twoThoudandOneAgain)

// let twoThoudandOneAgain1 = UInt8( twoThoudand )
// print(twoThoudandOneAgain1)


//______________________________________________________________

// Compiler Optimisation Happens
//			2. Associate/Infer Type Of RHS
//			3. Will Bind Type With LHS

let three = 3
let fractionPart = 0.14159

let piValue = Double(three) + fractionPart
print( piValue )


// Compiler Optimisation Happens
//		Constant Folding
//			1. Evaluate Constant Values
//			2. Associate/Infer Type For Evaluation Result
//			3. Will Bind Type With LHS
let piValueAgain = 3 + 0.14159
print( piValueAgain )


//______________________________________________________________

typealias AudioSample = UInt16
var maxAmplitude = AudioSample.max

//______________________________________________________________

let expression = -10

// If Is Type Safe Expression In Swift
// error: type 'Int' cannot be used as a boolean; test for '!= 0' instead
if expression == -10 {
	print("If Branch")
} else {
	print("Else Branch")
}

//______________________________________________________________

// In Swift Tuple Is Strictly Typed
//		Each Members Type Matters
let httpError: (Int, String) = (404, "Some Error")
print( httpError )
print( "\(httpError.0), \(httpError.1)" )

// error: cannot convert value of type '(Int, String)' to specified type '(Int, Int)'
// let something: (Int, Int) = httpError

//______________________________________________________________

// DESIGN PRINCIPLE
//		Design Towards Non NUllability Rather Than Nullabiliy

// var something = "Welcome!"
// something = null

// if (something != null ) {
// 		print( something.toUpper() )
// }

// Cyclomatic Complexity
//		Measurement Of Code Nestedness

let possibleNumber = "123" // String

// Data Conversion Happens In 2 Step Process
// 1. Type Conversion Happens
// 2. Data Conversion Happens
let convertedNumber = Int(possibleNumber)
if ( convertedNumber != nil ) {
	print( "\(possibleNumber) Have Value : \(convertedNumber!)")
} else {
	print("Met With Nothingness...")
}

// Swift Idiomatic Coding Style
// 1. possibleNumberr Converstion Happens : Type and Than Value
// 2. Checked For Nullability
// 3. If Not Nullable Then Unwrapping Will Happen
// 4. Unwrapped Value Binded With Local Constant In If Block
if let actualNumber = Int(possibleNumber) {
	print( "\(possibleNumber) Have Value : \(actualNumber)")
} else { 
	// print( "\(possibleNumber) Have Value : \(actualNumber)") //  error: cannot find 'actualNumber' in scope
	print("Met With Nothingness...")
}

// Compiler Will Generate Following Code For Above 5 Lines Of Code
// let tempConvertedNumber = Int(possibleNumber
// if (tempConvertedNumber ! = nil ) {
// 	let actualNumber = tempConvertedNumber!
// 	print( "\(possibleNumber) Have Value : \(actualNumber!)")
// } else {
// 	print("Met With Nothingness...")
// }

if let firstNumber = Int("43"), let secondNumber = Int("100"), let thirdNumber = Int("10") {
	let sum = firstNumber + secondNumber + thirdNumber
	print(" Sum : \(sum)")
} else {
	print("Met With Nothingness...")
}


let a: Int? = 80
let b: Int? = nil
let c: Int? = 90

if let A = a, let B = b, let C = c {
	print(A, B, C)
} else {
	print("Met With Nothing!")
}

//_________________________________________________

let names = ["Anna", "Alex", "Tom", "Harry"]

let count = names.count

for index in 0..<count {
	print( "Person \(index+1) : Is \(names[index])")
}

// Type Inferrencing
//		name Is Of Type String
for name in names {
	print(name)
	// name = "Hi" // error: cannot assign to value: 'name' is a 'let' constant
	// print(name)
}

//_________________________________________________

var someString = "Hello World!"
print(someString)

let preComposed: Character = "\u{D55C}"
print(preComposed)
// 한

let decomposed: Character =  "\u{1112}\u{1161}\u{11AB}"
print(decomposed)

