
import Foundation

//_________________________________________________________

struct Customer {
	let id: String
	let email: String
	let firstName: String?
	let lastName: String?
	let balance: Int
}

let customer = Customer(id: "30", 
		email: "customer@gmail.com",
		firstName: "Tom",
		lastName: "Harris",
		balance: 3000
	)

print(customer)

/*
// Optional Implementation In Swift Language
//		It's Implemented Using enum Construct
public enum Optional<Wrapped> {
	case none
	case some(Wrapped)
}
*/

switch customer.firstName {
case .some(let fname) : print( "First Name: \(fname)")
case .none: print( "First Name Doen't Exists")
}

switch customer.firstName {
// Here fname Will Contain Unwrapped Optional Value
case let fname? : print( "First Name: \(fname)") 
case nil: print( "First Name Doen't Exists")
}

// Following if-else Construct Is Equivalent To Above switch-case Construct Code
if let fName = customer.firstName {
	print( "First Name: \(fName)")
} else {
	print( "First Name Doen't Exists")
}

extension Customer: CustomStringConvertible {
    var description: String {
        var customDescription: String = "\(id), \(email)"
        
        if let firstName = firstName {
            customDescription += ", \(firstName)"
        }
        
        if let lastName = lastName {
            customDescription += " \(lastName)"
        }
        
        return customDescription
    }
}

print(customer)


// Swift Idiomatic Code
if let firstName = customer.firstName, let lastName = customer.lastName {
    print("Friend's full name is \(firstName) \(lastName)")
}

if let firstName = customer.firstName, customer.balance > 0 {
    let welcomeMessage = "Dear \(firstName), you have money on your account, want to spend it on mayonnaise?"
}

if let firstName = customer.firstName, 4500..<5000 ~= customer.balance {
    let notification = "Dear \(firstName), you are getting close to afford our $50 tub!"
}

// Various Kind Of Validation Patterns

if // Validation Logic
    let _ = customer.firstName,
    let _ = customer.lastName {
    print("The customer entered his full name")
}

if // Validation Logic
    customer.firstName != nil,
    customer.lastName != nil {
    print("The customer entered his full name")
}

if customer.firstName == nil, customer.lastName == nil {
    print("The customer has supplied a name")
}


//_________________________________________________________

struct Customer1 {
    let id: String
    let email: String
    let firstName: String?
    let lastName: String?
    let balance: Int

    var displayName: String? {
        // guard let firstName = firstName, let lastName = lastName else {
        //      return ""
        // }    
        // return "\(firstName) \(lastName)")

        // if let firstName = firstName, let lastName = lastName {
        //     return "\(firstName) \(lastName)")
        // } else {
        //     return ""
        // }

        // if let firstName = firstName, let lastName = lastName {
        //     return "\(firstName) \(lastName)")
        // } else {
        //     return nil
        // }

        // if let firstName = firstName, let lastName = lastName {
        //     return "\(firstName) \(lastName)")
        // } else {
        //     // throw Exceptions("Local Information");
        //     // Propograting Error To Callers
        //     //      Only When Caller Is Interested In It!

        //     // Breaking Encapsulation/Localisation
        // }

        switch (firstName, lastName) {
        case let (first?, last?): return first + "  " + last
        case let (first, nil) : return first
        case let (nil, last?) : return last
        // default: return nil
        }

    }
}

// let title : String = customer.displayName ?? "customer"
// print(title)


//_________________________________________________________

enum Membership {
    case gold
    case silver
}

struct Customer2 {
    // { .gold, .silver, nil}
    let membership: Membership?
}

let customer2 = Customer2(membership: .gold)

// 1. Checking customer2.membership is Not nil
// 2. If Not nil Than Unwrap It
// 3. Bind Uwrapped Value With membership Identifier
if let membership = customer2.membership {
    switch membership {
    case .gold : print("Gold")
    case .silver : print("Silver")
    }
}

// .gold?
// 1. Checking customer2.membership is Not nil
// 2. If Not nil Than Unwrap It
// 3. Bind Uwrapped Value With gold identifier

// .silver?
// 1. Checking customer2.membership is Not nil
// 2. If Not nil Than Unwrap It
// 3. Bind Uwrapped Value With silver identifier
switch customer2.membership {
    case .gold? : print("Gold")
    case .silver? : print("Silver")
    case nil : print("Nil Found")
}

// switch customer2.membership? {
//     case .gold : print("Gold")
//     case .silver : print("Silver")
//     case nil : print("Nil Found")
// }

//_________________________________________________________

// struct Service {
//     let name = "Download Service"
// }

// DownloadService {
//     let service: Service?
// }

// struct DownloadManger {
//     let downloadService : DownloadService?
// }

// struct FileManager {
//     let downloadManager : DownloadManger?
// }

// let fileManager = FileManager(downloadManager: DownloadManger(downloadService:DownloadService(service:Service())))

// let name: String? = fileManager.downloadManager?.downloadService?.service?.name


//_________________________________________________________

let preferences = ["autoLogin": true, "faceIdEnabled": true]

print( preferences["faceIdEnabled"] ) // Optional(true)

let isFaceIdEnabled = preferences["faceIdEnabled"]  ?? false

print(isFaceIdEnabled) // Now a Bool instead of Optional(Bool)

//: ## Falling back on true

if preferences["faceIdEnabled"] ?? true {
    // go to Face ID settings screen.
} else {
    // customer has disabled Face ID
}

//_________________________________________________________

// enum UserPreference: RawRepresentable {
//     case enabled
//     case disabled
//     case notSet
    
//     init(rawValue: Bool?) {
//         switch rawValue {
//         case true?: self = .enabled
//         case false?: self = .enabled
//         default: self = .notSet
//         }
//     }
    
//     var rawValue: Bool? {
//         switch self {
//         case .enabled: return true
//         case .disabled: return false
//         case .notSet: return nil
//         }
//     }
// }

// let preferences = ["autoLogin": true, "faceIdEnabled": true]
// let isFaceIdEnabled = preferences["faceIdEnabled"]
// print(isFaceIdEnabled) // Optional(true)

// // We convert the optional bool to an enum here.
// let faceIdPreference = UserPreference(rawValue: isFaceIdEnabled)
// // Now we can pass around the enum.
// // Implementers can match on it.
// switch faceIdPreference {
// case .enabled: print("Face ID is enabled")
// case .disabled: print("Face ID is disabled")
// case .notSet: print("Face ID preference is not set")
// }


//_________________________________________________________

// IMPLICITYLY UNWRAPPED OPTIONALS
//      Use it and only if, There Guarantee of Initiation Order

class ChatService {
    var isHealthy = true
    // More Code...
}

class WhatsAppMonitor {
    class func start() -> WhatsAppMonitor {
        return WhatsAppMonitor()
    }
    
    // DELEGATION DESIGN PATTERN
    // OR COMPOSITION DESIGN PATTERN
    // Optional Chat Service
    // var chatService: ChatService?

    // Implicitly Unwrapped Chat Service
     var chatService: ChatService! 
    func status() -> String {

         // error: optional type 'Bool?' cannot be used as a boolean; test for '!= nil' instead
        // if let chatService = chatService, chatService.isHealthy {
        if chatService.isHealthy {
            return "Everything is up and running"
        } else {
            return "Chatservice is down!"
        }
    }
}

// WHATS APP STARTING STAGES
// 1. WhatsApplication : UIApplication
// 2. WhatsApp Monitor Service
let whatsAppMonitor = WhatsAppMonitor.start()
//processMonitor.status() // fatal error: unexpectedly found nil

// 3. WhatsAppConfiguration Service Using Configuation Manager
// Allocation And Initialisatoin Done At By Configuration Manager
let chat = ChatService()
whatsAppMonitor.chatService = chat

//4. WhatsApp Is Up and Running : Ready For Usage
whatsAppMonitor.status() // "Everything is up and running"

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
 