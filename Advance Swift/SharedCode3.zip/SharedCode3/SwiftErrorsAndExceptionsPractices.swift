

import Foundation

//_________________________________________________________

// Summation Type
enum ParseLocationError: Error {
    case invalidData
    case locationDoesNotExist
    case middleOfTheOcean
}

// Product Type
struct MultipleParseLocationErrors: Error {
    let parsingErrors: [ParseLocationError]
    let isShownToUser: Bool
}

struct Location {
    let latitude: Double
    let longitude: Double
}

//_________________________________________________________

func parseLocation(_ latitude: String, _ longitude: String) throws -> Location {
    guard let latitude = Double(latitude), let longitude = Double(longitude) else {
        throw ParseLocationError.invalidData
    }
    
    return Location(latitude: latitude, longitude: longitude)
}

// error: call can throw but is not marked with 'try'
// parseLocation("I am not a double", "110")

do {
    try parseLocation("I am not a double", "110")
} catch {
    print(error) // invalidData
}

//_________________________________________________________


enum ListError: Error {
    case invalidValue
}

struct TodoList {
    
    private var values = [String]()

    // BAD DESIGN    
    // mutating func append(strings: [String]) throws {
    //    for string in strings {
    //        let trimmedString = string.trimmingCharacters(in: .whitespacesAndNewlines)

    //        if trimmedString.isEmpty {
    //            throw ListError.invalidValue
    //        } else {
    //            values.append(trimmedString)
    //        }
    //    }
    // }

    // GOOD DESIGN
    mutating func append(strings: [String]) throws {
        var trimmedStrings = [String]()
        for string in strings {
            let trimmedString = string.trimmingCharacters(in: .whitespacesAndNewlines)
            
            if trimmedString.isEmpty {
                throw ListError.invalidValue
            } else {
                trimmedStrings.append(trimmedString)
            }
        }
        
        // Only when everything succeeds, do we start mutating the struct.
        values.append(contentsOf: trimmedStrings)
    }

}

//_________________________________________________________

var number = 10
var divisor = 90
var result = 0

// BAD CODE DESIGN
// Validation Logic CAN BE DONE WITH JUST if-else construction
do {
    try result = number / divisor
} catch {
    print(error)
}

//_________________________________________________________

import PlaygroundSupport

func writeToFiles(data: [URL: String]) throws {
    var storedUrls = [URL]()

    defer {
        if storedUrls.count != data.count {
            for url in storedUrls {
                try! FileManager.default.removeItem(at: url)
            }
        }
    }
    
    for (url, contents) in data {
        try contents.write(to: url, atomically: true, encoding: String.Encoding.utf8)
        storedUrls.append(url)
    }
}

let url = playgroundSharedDataDirectory.appendingPathComponent("somefile.txt")

do {
    try writeToFiles(data: [url: "Hello there"])
} catch {
    print(error)
}

//_________________________________________________________
//_________________________________________________________

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
