import Foundation

//_________________________________________________________

// Product Type
//		Number Of Choices Are Calculated By Product Of Cases

struct Message {
	let userId: String
	let date: Date

	// Five Properties Are Mutually Exclusive
	let contents: String?
	let hasJoined: Bool
	let hasLeft: Bool

	// Two Properties Are Mutually Exclusive
	let isBeingDrafted: Bool
	let isSendingBollons: Bool	
}

let joinMessage = Message(userId: "100", 
	date: Date(),
	contents: nil, 
	hasJoined: true, 
	hasLeft: false, 
	isBeingDrafted: false, 
	isSendingBollons: false)

let textMessage = Message(userId: "101", 
	date: Date(),	 
	contents: "Hello! How are you doing?", 
	hasJoined: false, 
	hasLeft: false, 
	isBeingDrafted: false, 
	isSendingBollons: false)

//_________________________________________________________


let badMessage = Message(userId: "101",
	date: Date(), 
	contents: "Hello! How are you doing?", 
	hasJoined: true, 
	hasLeft: true, 
	isBeingDrafted: false, 
	isSendingBollons: false)

//_________________________________________________________

// MessageAgain Type
//		Range = { text, draft, join, leave, ballon }

// Summation Type
//		Number Of Choices Are Calculated By Summation Of Cases
enum MessageAgain {
	case text(userId: String, contents: String, date: Date)
	case draft(userId: String, date: Date)
	case join(userId: String, date: Date)
	case leave(userId: String, date: Date)
	case ballon(userId: String, date: Date)
}

let textMessageAgain = MessageAgain.text(userId: "101", contents: "HEllo!", date: Date())
let joinMessageAgain = MessageAgain.join(userId: "100", date: Date())

func logMessage( message: MessageAgain) {
	// Switch in Swift Is Type Safe Construct
	switch message {
	case let .text(userId, contents, date):
		print("\(userId), \(contents), \(date)")
	case let .draft(userId, date ):
		print("\(userId), \(date)")
	case let .join(userId, date ):
		print("\(userId), \(date)")
	case let .leave(userId, date ):
		print("\(userId), \(date)")
	case let .ballon(userId, date ):	
		print("\(userId), \(date)")
	}
}

logMessage(message: textMessageAgain)
logMessage(message: joinMessageAgain)

// if case let Message.text(_, contents: contents, _) = textMessageAgain {
// 	print("Recieved Message: \(contents)")
// }


//_________________________________________________________

// Suppose Employee, Student and Player Is Subclass of Student
//let arrAgain: [Person] = [ Employee(), Student(), Player() ]

let arr: [Any] = [ Date(), "Something Here...", "Some Life!", 999 ]

for element : Any in arr {
	switch element {
	case let stringValue as String : print(" \(stringValue) ")
	case let intValue as Int : print("\(intValue)")
	case let dateValue as Date: print("\(dateValue)")
	default: print("Default Case...")
	}
}

// Eliminating Any From Code Using Enums
enum DateType {
case singleDate(Date)
case dateRange(Range<Date>)
}

let now = Date()
let hourFromNow = Date(timeIntervalSinceNow: 3600)

// dates Is Polymorphic Array
let dates: [DateType] = [
	DateType.singleDate(now),
	DateType.dateRange(now..<hourFromNow)
]

for dateType in dates {
	switch dateType {
	case .singleDate(let date): print( "\(date)")
	case .dateRange(let range): print( "\(range)")
	}
}

//_________________________________________________________

/*
struct Run {
	let id: String 
	let startTime: Date
	let endTime: Date
	let distance: Float
	let onRunningTrack: Bool
}

struct Cycle {
	enum CycleType {
		case regular
		case mountainBike
		case racetrack
	}

	let id: String 
	let startTime: Date
	let endTime: Date
	let distance: Float
	let incline: Int
	let type: CycleType
}

let run = Run(id: "100",
				startTime: Date(), 
				endTime: Date(timeIntervalSinceNow: 4000),
				distance: 3000,
				onRunningTrack: false
			)

let cycle = Cycle(id: "101",
				startTime: Date(), 
				endTime: Date(timeIntervalSinceNow: 4000),
				distance: 3000,
				incline: 10,
				type: .regular
			)

*/

//_________________________________________________________

/*
// DRY Priciple
//		Don't Repeat Yourself

// Generalisation
class Workout {
	let id: String 
	let startTime: Date
}

// Specialisation
class RunWorkout : Workout {
	let endTime: Date	
	let distance: Float	
	let onRunningTrack: Bool
}

class CycleWorkout: Workout {
	enum CycleType {
		case regular
		case mountainBike
		case racetrack
	}

	let endTime: Date	
	let distance: Float	
	let incline: Int
	let type: CycleType
}

class PushupWorkout : Workout {
	let repetitions: [Int]
	let date: Date
}

class YogaWorkout : Workout {
	let repetitions: [Int]
	let date: Date
}

*/

//_________________________________________________________

struct Run {
	let id: String 
	let startTime: Date
	let endTime: Date
	let distance: Float
	let onRunningTrack: Bool
}

struct Cycle {
	enum CycleType {
		case regular
		case mountainBike
		case racetrack
	}

	let id: String 
	let startTime: Date
	let endTime: Date
	let distance: Float
	let incline: Int
	let type: CycleType
}

struct Pushups {
	let repetitions: [Int]
	let date: Date
}

struct Yoga {
	let repetitions: [Int]
	let date: Date
}

let run = Run(id: "100",
				startTime: Date(), 
				endTime: Date(timeIntervalSinceNow: 4000),
				distance: 3000,
				onRunningTrack: false
			)

let cycle = Cycle(id: "101",
				startTime: Date(), 
				endTime: Date(timeIntervalSinceNow: 4000),
				distance: 3000,
				incline: 10,
				type: .regular
			)

// Will Help In Polymorphism 
enum Workout {
	case run(Run)
	case cycle(Cycle)
	case pushups(Pushups)
	case yoga(Yoga)
}

let pushups = Pushups(repetitions: [10, 20, 30], date: Date() )
let workout = Workout.pushups(pushups)

switch workout {
case .run(let run):
	print("\(run)")
case .cycle(let cycle):
	print("\(cycle)")
case .pushups(let pushups):	
	print("\(pushups)")
case .yoga(let yoga):	
	print("\(yoga)")
}

//_________________________________________________________

enum Day {
    case sunday
    case monday
    case tuesday
    case wednesday
    case thursday
    case friday
    case saturday
}

enum Age {
    case known(UInt8)
    case unknown
}

struct BooleanContainer {
    let first: Bool
    let second: Bool
}

print(BooleanContainer(first: true, second: true))
print(BooleanContainer(first: true, second: false))
print(BooleanContainer(first: false, second: true))
print(BooleanContainer(first: false, second: false))

//___________________________________
// Combining Following Two Types As One Enum Summation Type

enum PaymentType {
    case invoice
    case creditcard
    case cash
}

struct PaymentStatus {
    let paymentDate: Date?
    let isRecurring: Bool
    let paymentType: PaymentType
}

//
//// Alternatively, the enum and struct can be turned into a single struct.
enum PaymentStatusEnum {
   case invoice(paymentDate: Date?, isRecurring: Bool)
   case creditcard(paymentDate: Date?, isRecurring: Bool)
   case cash(paymentDate: Date?, isRecurring: Bool)
}

//_________________________________________________________

// enum Currency: String {
//     case euro = "euro"
//     case usd = "usd"
//     case gbp = "gdp"
// }

enum Currency: String {
    case euro = "eur"
    case usd
    case gbp
}

var currency = Currency.euro
print(currency.rawValue) // "usd"

currency = Currency.usd
print(currency.rawValue) // "usd"

let parameters = ["filter": currency.rawValue]
print(parameters) // ["filter": "euro"]

var parametersArray: [String: String]
switch currency {
case .euro: parametersArray = ["filter...": "euro"]
case .usd: parametersArray = ["filter...": "usd"]
case .gbp: parametersArray = ["filter...": "gbp"]
}

print(parametersArray)

// BAD CODING PRACTICE
// Not A Type Safe Code
// 		rawValue Calculations Happens At Runtime 
switch currency.rawValue {
case "eur": parametersArray = ["filter...": "euro"]
case "usd": parametersArray = ["filter...": "usd"]
case "gbp": parametersArray = ["filter...": "gbp"]
default: print("Default...")
}

//_________________________________________________________

enum CurrencyAgain: String {
    case euro
    case usd
    case gbp
}

let currency1 = CurrencyAgain.euro
print(currency1.rawValue) // "euro"


let parameters1 = ["filter": currency1.rawValue]
print(parameters1) // ["filter": "euro"]

//_________________________________________________________

// GOOD PATTERN
enum ImageType: String {
    case jpg
    case bmp
    case gif
    
    init?(rawValue: String) {
        switch rawValue.lowercased() {
        case "jpg", "jpeg": self = .jpg
        case "bmp", "bitmap": self = .bmp
        case "gif", "gifv": self = .gif
        default: return nil
        }
    }
}

func iconName(for fileExtension: String) -> String {
    guard let imageType = ImageType(rawValue: fileExtension) else {
        return "assetIconUnknown"
    }

    // Type Safe Code
    switch imageType {
    case .jpg: return "assetIconJpeg"
    case .bmp: return "assetIconBitmap"
    case .gif: return "assetIconGif"
    }
}

print(iconName(for: "jpg") )// "Received jpg"
print(iconName(for: "jpeg") )// "Received jpg"
print(iconName(for: "JPG") )// "Received a jpg"
print(iconName(for: "JPEG") )// "Received a jpg"
print(iconName(for: "gif") )// "Received a gif"

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________


