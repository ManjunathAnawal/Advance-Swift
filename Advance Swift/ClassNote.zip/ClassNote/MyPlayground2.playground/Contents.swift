class Person {
    let name : String?
    var tit: String?
    lazy var desc: () -> String =  {
        "\(self.name) byy \(self.tit)"

    }
    init(name: String){
//        self.dependency = dependency
        self.name = name
    }
    deinit{
        print("I am dying person ")
    }
}
let desc : String
do {
    let person1 = Person(name: "person1")
   
    desc =  person1.desc()

}


