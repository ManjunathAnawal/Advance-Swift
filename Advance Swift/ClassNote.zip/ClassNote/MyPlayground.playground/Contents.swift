import Foundation
import Darwin

class Node {
    var data: Int
    var next: Node?
    
    init(_ data: Int, _ next: Node? = nil) {
        self.data = data
        self.next = next
    }

}

let node3 = Node(30)
let node2 = Node(20,node3)
let node1 = Node(10,node2)

func traverseLinkedList(_ head: Node?) {
    if head == nil { return }
    var node = head
    print(node!.data)
    while node?.next != nil {
        node = node?.next
        print(node!.data)
    }
}

traverseLinkedList(node1)
