
import Foundation

let arr: [Int] = [3]
for i in 0...arr.count
{
    print(i)
}

