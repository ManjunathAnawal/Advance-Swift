//
//  main.swift
//  temp
//
//  Created by Manjunath on 29/04/22.
//


import Foundation
import PlaygroundSupport
import UIKit

func loadFile(name: String) -> Data? {
    let url = playgroundSharedDataDirectory.appendingPathComponent(name)
    return try? Data(contentsOf: url)
    
}
@discardableResult func storeData(image: UIImage, url: URL) -> Bool {
    guard let data = image.pngData() else {
        return false
}
do {
    try data.write(to: url)
    return true
    } catch {
        return false
}
}
 let image = UIImage()
let url = playgroundSharedDataDirectory.appendingPathComponent("image")
storeData(image: image, url: url)
