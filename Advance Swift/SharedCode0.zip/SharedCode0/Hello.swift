
import Foundation

print("Hello!")

// DESIGN PRINCIPLE
//		Design Towards Immutability Rather Than Mutability	
//	

// IMMUTABLE Property
let maximumNumberOfLogins = 10

// MUTABLE
var currentLoginAttempts = 0

print( maximumNumberOfLogins )
print( currentLoginAttempts )


// Desinging Towards Immutability Rather Than Mutability
// Local Context Changes
//		Changes Are Happening In Some Function
// var maximumNumberOfLoginsLocal = maximumNumberOfLogins
// maximumNumberOfLoginsLocal = 90


// Type Of greeting???

//1. Type Inferrencing
//		Type Is Inferred From RHS. Value
//			i.e. "" Is String Type Value
//2. Type Binding
// 		LHS Identtifier Is Binded With Inferred Type
//		Compile Time Decision

let greeting = "Good Morning!"


//1. Type Inferrencing
//		Type Is Inferred From RHS. Value
//			i.e. "" Is String Type Value
//2. Type Conformance
// 		LHS Identtifier Type Conforms To Type As RHS Inferred Type


// Type Annotation
let greetingAgain: String = "Good Morning!"

// error: cannot convert value of type 'Int' to specified type 'String'
//  let greetingAgain1: String = 100


// In Java Following Is Possible
//		Implicit Type Conversion Happens from Int To String
// String greeting = 900;
//  "Hello World!" + 90;

print( greeting )
print( greetingAgain )


// _____________________________________________________________


//  WHAT IS A DATA TYPE OR TYPE ???
//

// Type Safe Language
// 		What Is Type Safety???
//		Never Violate Type Definition

//______________________________________________________________

let minValue = UInt8.min
let maxValue = UInt8.max

print(minValue)
print(maxValue)

//______________________________________________________________


let twoThoudand: UInt16 = 2000
let one: UInt8 = 1

// binary operator '+' cannot be applied to operands of type 'UInt16' and 'UInt8'
// let twoThoudandOne = twoThoudand + one
// print(twoThoudandOne)

let twoThoudandOne = twoThoudand + UInt16( one )
print(twoThoudandOne)

// Fatal error: Not enough bits to represent the passed value
// let twoThoudandOneAgain = UInt8( twoThoudand ) + one  
// print(twoThoudandOneAgain)

// let twoThoudandOneAgain1 = UInt8( twoThoudand )
// print(twoThoudandOneAgain1)


//______________________________________________________________

// Compiler Optimisation Happens
//			2. Associate/Infer Type Of RHS
//			3. Will Bind Type With LHS

let three = 3
let fractionPart = 0.14159

let piValue = Double(three) + fractionPart
print( piValue )


// Compiler Optimisation Happens
//		Constant Folding
//			1. Evaluate Constant Values
//			2. Associate/Infer Type For Evaluation Result
//			3. Will Bind Type With LHS
let piValueAgain = 3 + 0.14159
print( piValueAgain )


//______________________________________________________________

typealias AudioSample = UInt16
var maxAmplitude = AudioSample.max

//______________________________________________________________


let expression = -10

if expression {
	print("If Branch")
} else {
	print("Else Branch")
}

