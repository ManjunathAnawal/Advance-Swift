
#include <stdio.h>

// Choices
//	A. CTE
//	B. RTE
//	C. If Branch
//	D. else Branch

int main() {
	int expression = -10;

	if (expression) {
		printf("If Branch"\n");
	} else {
		printf("Else Branch"\n");
	}
}

