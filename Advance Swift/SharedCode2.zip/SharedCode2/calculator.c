
#include <stdio.h>


// All These Functions Are Single Units
int sum( int x, int y ) {  return x + y ; }
int sub( int x, int y ) {  return x - y ; }
int mul( int x, int y ) {  return x * y ; }
int div( int x, int y ) {  return x / y ; }

// Polymporhic Functions
int calculator(int x, int y, int (*operation )(int, int ) )  {
	return operation(x, y);
}

int main() {
	int x = 40, y = 10, result = 0;

	result = calculator(x, y, sum);
	printf("Result : %d\n", result);

	result = calculator(x, y, sub);
	printf(" Result : %d \n", result);


	result = calculator(x, y, mul);
	printf(" Result : %d \n", result);
}

