
import Foundation

//_________________________________________________________

struct Customer {
	let id: String
	let email: String
	let firstName: String?
	let lastName: String?
	let balance: Int
}

let customer = Customer(id: "30", 
		email: "customer@gmail.com",
		firstName: "Tom",
		lastName: "Harris",
		balance: 3000
	)

print(customer)

/*
// Optional Implementation In Swift Language
//		It's Implemented Using enum Construct
public enum Optional<Wrapped> {
	case none
	case some(Wrapped)
}
*/

switch customer.firstName {
case .some(let fname) : print( "First Name: \(fname)")
case .none: print( "First Name Doen't Exists")
}

switch customer.firstName {
// Here fname Will Contain Unwrapped Optional Value
case let fname? : print( "First Name: \(fname)") 
case nil: print( "First Name Doen't Exists")
}

// Following if-else Construct Is Equivalent To Above switch-case Construct Code
if let fName = customer.firstName {
	print( "First Name: \(fName)")
} else {
	print( "First Name Doen't Exists")
}

extension Customer: CustomStringConvertible {
    var description: String {
        var customDescription: String = "\(id), \(email)"
        
        if let firstName = firstName {
            customDescription += ", \(firstName)"
        }
        
        if let lastName = lastName {
            customDescription += " \(lastName)"
        }
        
        return customDescription
    }
}

print(customer)


// Swift Idiomatic Code
if let firstName = customer.firstName, let lastName = customer.lastName {
    print("Friend's full name is \(firstName) \(lastName)")
}

if let firstName = customer.firstName, customer.balance > 0 {
    let welcomeMessage = "Dear \(firstName), you have money on your account, want to spend it on mayonnaise?"
}

if let firstName = customer.firstName, 4500..<5000 ~= customer.balance {
    let notification = "Dear \(firstName), you are getting close to afford our $50 tub!"
}

if // Validation Logic
    let _ = customer.firstName,
    let _ = customer.lastName {
    print("The customer entered his full name")
}

if // Validation Logic
    customer.firstName != nil,
    customer.lastName != nil {
    print("The customer entered his full name")
}

if customer.firstName == nil, customer.lastName == nil {
    print("The customer has supplied a name")
}


//_________________________________________________________


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
