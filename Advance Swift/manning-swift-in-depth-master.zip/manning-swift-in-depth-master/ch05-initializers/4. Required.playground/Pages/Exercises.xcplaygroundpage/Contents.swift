//: [Table of contents](Table%20of%20contents) - [Previous page](@previous) - [Next page](@next)
//: # Exercises
//: 1. Would required initializers make sense on structs, why or why not?
//: 2. Can you name two reasons for needing required initializers?

//: [Table of contents](Table%20of%20contents) - [Previous page](@previous) - [Next page](@next)

