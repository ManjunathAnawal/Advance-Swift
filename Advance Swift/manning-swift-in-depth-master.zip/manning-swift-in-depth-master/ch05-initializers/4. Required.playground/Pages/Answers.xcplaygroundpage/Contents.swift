//: [Table of contents](Table%20of%20contents) - [Previous page](@previous) - [Next page](@next)

//: # Answers
//: 1. No, requires initializers are to enforce subclasses to implement an initializer. Structs can't be subclassed.
//: 2. Factory methods and when a class adheres to a protocol with a declared initializer.

//: [Table of contents](Table%20of%20contents) - [Previous page](@previous) - [Next page](@next)


