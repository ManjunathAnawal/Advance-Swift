//: [Table of contents](Table%20of%20contents) - [Previous page](@previous)

//: # Exercise: Implicitly Unwrapped Optionals

//: Question: What are good alternatives to Implicitly Unwrapped Optionals?

//: Answer: Lazy properties or factories that are passed via an initializer.


//: [Table of contents](Table%20of%20contents) - [Previous page](@previous)
